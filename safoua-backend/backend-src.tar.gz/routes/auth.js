/**
 * routes/auth.js — Safoua Academy
 * ─────────────────────────────────
 * Handles: login, register, /me, update-progress
 *
 * FIX 1 (extracted from server.js monolith)
 * FIX 2 (rate limiting on login + register to prevent brute-force)
 */

import express from 'express';
import bcrypt  from 'bcrypt';
import jwt     from 'jsonwebtoken';
import User    from '../models/User.js';
import authMiddleware from '../middleware/authMiddleware.js';

const router = express.Router();

// ── INPUT VALIDATORS ───────────────────────────────────────────────
function validateEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}
function validatePassword(password) {
  return typeof password === 'string' && password.length >= 6;
}

// ── JWT HELPER ──────────────────────────────────────────────────────
function signToken(user) {
  return jwt.sign(
    { id: user._id, username: user.username, email: user.email, role: user.role || 'student' },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// ── IN-MEMORY RATE LIMITER (auth routes) ───────────────────────────
// Max 10 attempts per IP per minute on login & register.
const authRateLimitMap = new Map();

setInterval(() => {
  const now = Date.now();
  for (const [ip, times] of authRateLimitMap.entries()) {
    const filtered = times.filter(t => now - t < 60_000);
    if (filtered.length === 0) authRateLimitMap.delete(ip);
    else authRateLimitMap.set(ip, filtered);
  }
}, 5 * 60 * 1000);

function authRateLimit(req, res, next) {
  const ip  = req.ip || req.headers['x-forwarded-for'] || 'unknown';
  const now = Date.now();
  if (!authRateLimitMap.has(ip)) authRateLimitMap.set(ip, []);
  const times = authRateLimitMap.get(ip).filter(t => now - t < 60_000);
  if (times.length >= 10) {
    return res.status(429).json({ error: 'Trop de tentatives. Réessayez dans une minute.' });
  }
  times.push(now);
  authRateLimitMap.set(ip, times);
  next();
}

// ── POST /api/login ─────────────────────────────────────────────────
router.post('/login', authRateLimit, async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password)
      return res.status(400).json({ error: 'Email et mot de passe requis.' });
    if (!validateEmail(email))
      return res.status(400).json({ error: "Format d'email invalide." });

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user)
      return res.status(400).json({ error: 'Utilisateur non trouvé.' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ error: 'Mot de passe incorrect.' });

    const token = signToken(user);
    res.status(200).json({
      message: 'Connexion réussie ! 👋',
      token,
      user: { id: user._id, username: user.username, email: user.email, role: user.role || 'student' },
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Erreur lors de la connexion.' });
  }
});

// ── POST /api/register ──────────────────────────────────────────────
router.post('/register', authRateLimit, async (req, res) => {
  try {
    const { username, email, password, role, teacherCode } = req.body;

    // Teacher registration requires a secret code
    if (role === 'teacher') {
      if (!teacherCode || teacherCode !== process.env.TEACHER_CODE)
        return res.status(403).json({ error: 'Code enseignant invalide.' });
    }

    if (!username || !email || !password)
      return res.status(400).json({ error: 'Tous les champs sont requis.' });
    if (!validateEmail(email))
      return res.status(400).json({ error: "Format d'email invalide." });
    if (!validatePassword(password))
      return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' });
    if (role && !['student', 'teacher'].includes(role))
      return res.status(400).json({ error: 'Rôle invalide.' });

    const exists = await User.findOne({ email: email.toLowerCase().trim() });
    if (exists)
      return res.status(400).json({ error: 'Cet email est déjà utilisé.' });

    const salt           = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = new User({
      username: username.trim(),
      email:    email.toLowerCase().trim(),
      password: hashedPassword,
      role:     role || 'student',
    });
    await newUser.save();
    res.status(201).json({ message: 'Utilisateur créé avec succès ! 🛡️' });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: "Erreur lors de l'inscription." });
  }
});

// ── GET /api/me ─────────────────────────────────────────────────────
router.get('/me', authMiddleware, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user)
      return res.status(404).json({ error: 'Utilisateur non trouvé.' });
    res.json({
      id:               user._id,
      username:         user.username,
      email:            user.email,
      role:             user.role || 'student',
      completedLessons: user.completedLessons,
      points:           user.points,
    });
  } catch (err) {
    console.error('Get me error:', err);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ── POST /api/update-progress ───────────────────────────────────────
router.post('/update-progress', authMiddleware, async (req, res) => {
  const { lessonTitle } = req.body;
  if (!lessonTitle)
    return res.status(400).json({ error: 'Titre de leçon requis.' });
  try {
    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $addToSet: { completedLessons: lessonTitle }, $inc: { points: 10 } },
      { new: true }
    );
    if (!user)
      return res.status(404).json({ error: 'Utilisateur non trouvé.' });
    res.json({ message: 'Succès', points: user.points });
  } catch (err) {
    console.error('Update progress error:', err);
    res.status(500).json({ error: 'Erreur lors de la mise à jour.' });
  }
});

export default router;
