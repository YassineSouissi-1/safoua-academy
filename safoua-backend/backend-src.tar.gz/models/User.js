import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  username:  { type: String, required: true },
  email:     { type: String, required: true, unique: true },
  password:  { type: String, required: true },
  role: {
    type:    String,
    enum:    ["student", "teacher"],
    default: "student",
  },
  // Each entry: "Course Title — Module Title — Lesson Title"
  completedLessons: { type: [String], default: [] },
  points:           { type: Number,  default: 0 },
}, { timestamps: true });

export default mongoose.model('User', userSchema);